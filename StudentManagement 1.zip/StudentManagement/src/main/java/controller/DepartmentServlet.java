package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.DepartmentDAO;
import model.Department;

@WebServlet("/DepartmentServlet")
public class DepartmentServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        String role = (String)session.getAttribute("role");

        // AUTHORIZATION CHECK

        if(role == null || !role.equals("Admin")){

        	if(role.equals("Admin")){

        	    response.sendRedirect("adminDashboard.jsp");

        	}else{

        	    response.sendRedirect("employeeDashboard.jsp");
        	}
            return;
        }

        String action = request.getParameter("action");

        DepartmentDAO dao = new DepartmentDAO();

        // ADD

        if(action.equals("add")){

            String deptName =
                    request.getParameter("deptName");

            int industryId =
                    Integer.parseInt(request.getParameter("industryId"));

            String managerName =
                    request.getParameter("managerName");

            Department d = new Department();

            d.setDeptName(deptName);
            d.setIndustryId(industryId);
            d.setManagerName(managerName);

            dao.addDepartment(d);

            response.sendRedirect("department.jsp");
        }

        // UPDATE

        else if(action.equals("update")){

            int deptId =
                    Integer.parseInt(request.getParameter("deptId"));

            String deptName =
                    request.getParameter("deptName");

            int industryId =
                    Integer.parseInt(request.getParameter("industryId"));

            String managerName =
                    request.getParameter("managerName");

            Department d = new Department();

            d.setDeptId(deptId);
            d.setDeptName(deptName);
            d.setIndustryId(industryId);
            d.setManagerName(managerName);

            dao.updateDepartment(d);

            response.sendRedirect("department.jsp");
        }
    }

    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        String role = (String)session.getAttribute("role");

        // AUTHORIZATION CHECK

        if(role == null || !role.equals("Admin")){

            response.sendRedirect("dashboard.jsp");
            return;
        }

        String action = request.getParameter("action");

        DepartmentDAO dao = new DepartmentDAO();

        // DELETE

        if(action.equals("delete")){

            int id =
                    Integer.parseInt(request.getParameter("id"));

            dao.deleteDepartment(id);

            response.sendRedirect("department.jsp");
        }

        // EDIT

        else if(action.equals("edit")){

            int id =
                    Integer.parseInt(request.getParameter("id"));

            Department department =
                    dao.getDepartmentById(id);

            request.setAttribute("department", department);

            request.getRequestDispatcher("editDepartment.jsp")
                    .forward(request, response);
        }
    }
}