package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.EmployeeDAO;
import model.Employee;

@WebServlet("/EmployeeServlet")
public class EmployeeServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        String role = (String)session.getAttribute("role");

        // AUTHORIZATION CHECK

        if(role == null || !role.equals("Admin")){

        	if(role.equals("Admin")){

        	    response.sendRedirect("adminDashboard.jsp");

        	}else{

        	    response.sendRedirect("employeeDashboard.jsp");
        	}
            return;
        }

        String action = request.getParameter("action");

        EmployeeDAO dao = new EmployeeDAO();

        // ADD

        if(action.equals("add")){

            String name = request.getParameter("name");
            String email = request.getParameter("email");
            String phone = request.getParameter("phone");

            int deptId =
                    Integer.parseInt(request.getParameter("deptId"));

            String empRole =
                    request.getParameter("role");

            double salary =
                    Double.parseDouble(request.getParameter("salary"));

            Employee e = new Employee();

            e.setName(name);
            e.setEmail(email);
            e.setPhone(phone);
            e.setDeptId(deptId);
            e.setRole(empRole);
            e.setSalary(salary);

            dao.addEmployee(e);

            response.sendRedirect("employee.jsp");
        }

        // UPDATE

        else if(action.equals("update")){

            int empId =
                    Integer.parseInt(request.getParameter("empId"));

            String name = request.getParameter("name");
            String email = request.getParameter("email");
            String phone = request.getParameter("phone");

            int deptId =
                    Integer.parseInt(request.getParameter("deptId"));

            String empRole =
                    request.getParameter("role");

            double salary =
                    Double.parseDouble(request.getParameter("salary"));

            Employee e = new Employee();

            e.setEmpId(empId);
            e.setName(name);
            e.setEmail(email);
            e.setPhone(phone);
            e.setDeptId(deptId);
            e.setRole(empRole);
            e.setSalary(salary);

            dao.updateEmployee(e);

            response.sendRedirect("employee.jsp");
        }
    }

    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        String role = (String)session.getAttribute("role");

        // AUTHORIZATION CHECK

        if(role == null || !role.equals("Admin")){

            response.sendRedirect("dashboard.jsp");
            return;
        }

        String action = request.getParameter("action");

        EmployeeDAO dao = new EmployeeDAO();

        // DELETE

        if(action.equals("delete")){

            int id =
                    Integer.parseInt(request.getParameter("id"));

            dao.deleteEmployee(id);

            response.sendRedirect("employee.jsp");
        }

        // EDIT

        else if(action.equals("edit")){

            int id =
                    Integer.parseInt(request.getParameter("id"));

            Employee employee =
                    dao.getEmployeeById(id);

            request.setAttribute("employee", employee);

            request.getRequestDispatcher("editEmployee.jsp")
                    .forward(request, response);
        }
    }
}