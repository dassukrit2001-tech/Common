package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.IndustryDAO;
import model.Industry;

@WebServlet("/IndustryServlet")
public class IndustryServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        String role = (String)session.getAttribute("role");

        // AUTHORIZATION CHECK

        if(role == null || !role.equals("Admin")){

        	if(role.equals("Admin")){

        	    response.sendRedirect("adminDashboard.jsp");

        	}else{

        	    response.sendRedirect("employeeDashboard.jsp");
        	}
            return;
        }

        String action = request.getParameter("action");

        IndustryDAO dao = new IndustryDAO();

        // ADD

        if(action.equals("add")){

            String industryName =
                    request.getParameter("industryName");

            String location =
                    request.getParameter("location");

            String type =
                    request.getParameter("type");

            Industry i = new Industry();

            i.setIndustryName(industryName);
            i.setLocation(location);
            i.setType(type);

            dao.addIndustry(i);

            response.sendRedirect("industry.jsp");
        }

        // UPDATE

        else if(action.equals("update")){

            int id =
                    Integer.parseInt(request.getParameter("industryId"));

            String industryName =
                    request.getParameter("industryName");

            String location =
                    request.getParameter("location");

            String type =
                    request.getParameter("type");

            Industry i = new Industry();

            i.setIndustryId(id);
            i.setIndustryName(industryName);
            i.setLocation(location);
            i.setType(type);

            dao.updateIndustry(i);

            response.sendRedirect("industry.jsp");
        }
    }

    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        String role = (String)session.getAttribute("role");

        if(role == null || !role.equals("Admin")){

            response.sendRedirect("dashboard.jsp");
            return;
        }

        String action = request.getParameter("action");

        IndustryDAO dao = new IndustryDAO();

        // DELETE

        if(action.equals("delete")){

            int id =
                    Integer.parseInt(request.getParameter("id"));

            dao.deleteIndustry(id);

            response.sendRedirect("industry.jsp");
        }

        // EDIT

        else if(action.equals("edit")){

            int id =
                    Integer.parseInt(request.getParameter("id"));

            Industry industry =
                    dao.getIndustryById(id);

            request.setAttribute("industry", industry);

            request.getRequestDispatcher("editIndustry.jsp")
                    .forward(request, response);
        }
    }
}