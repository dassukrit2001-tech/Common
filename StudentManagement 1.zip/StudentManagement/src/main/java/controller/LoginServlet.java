package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.UserDAO;
import model.User;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        UserDAO dao = new UserDAO();

        User user = dao.loginUser(email, password);

        if(user != null){

            HttpSession session = request.getSession();

            session.setAttribute("user", user);
            session.setAttribute("name", user.getName());
            session.setAttribute("role", user.getRole());

            // ROLE BASED REDIRECT

            if(user.getRole().equals("Admin")){

                response.sendRedirect("adminDashboard.jsp");

            }else if(user.getRole().equals("Employee")){

                response.sendRedirect("employeeDashboard.jsp");
            }

        }else{

            response.sendRedirect("login.jsp?msg=Invalid");
        }
    }
}