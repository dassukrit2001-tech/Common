package controller;

import java.io.IOException;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.ProjectDAO;
import model.Project;

@WebServlet("/ProjectServlet")
public class ProjectServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        String role = (String)session.getAttribute("role");

        // AUTHORIZATION CHECK

        if(role == null || !role.equals("Admin")){

        	if(role.equals("Admin")){

        	    response.sendRedirect("adminDashboard.jsp");

        	}else{

        	    response.sendRedirect("employeeDashboard.jsp");
        	}
            return;
        }

        String action = request.getParameter("action");

        ProjectDAO dao = new ProjectDAO();

        // ADD

        if(action.equals("add")){

            String projectName =
                    request.getParameter("projectName");

            Date startDate =
                    Date.valueOf(request.getParameter("startDate"));

            Date endDate =
                    Date.valueOf(request.getParameter("endDate"));

            int deptId =
                    Integer.parseInt(request.getParameter("deptId"));

            String status =
                    request.getParameter("status");

            Project p = new Project();

            p.setProjectName(projectName);
            p.setStartDate(startDate);
            p.setEndDate(endDate);
            p.setDeptId(deptId);
            p.setStatus(status);

            dao.addProject(p);

            response.sendRedirect("project.jsp");
        }

        // UPDATE

        else if(action.equals("update")){

            int projectId =
                    Integer.parseInt(request.getParameter("projectId"));

            String projectName =
                    request.getParameter("projectName");

            Date startDate =
                    Date.valueOf(request.getParameter("startDate"));

            Date endDate =
                    Date.valueOf(request.getParameter("endDate"));

            int deptId =
                    Integer.parseInt(request.getParameter("deptId"));

            String status =
                    request.getParameter("status");

            Project p = new Project();

            p.setProjectId(projectId);
            p.setProjectName(projectName);
            p.setStartDate(startDate);
            p.setEndDate(endDate);
            p.setDeptId(deptId);
            p.setStatus(status);

            dao.updateProject(p);

            response.sendRedirect("project.jsp");
        }
    }

    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        String role = (String)session.getAttribute("role");

        // AUTHORIZATION CHECK

        if(role == null || !role.equals("Admin")){

            response.sendRedirect("dashboard.jsp");
            return;
        }

        String action = request.getParameter("action");

        ProjectDAO dao = new ProjectDAO();

        // DELETE

        if(action.equals("delete")){

            int id =
                    Integer.parseInt(request.getParameter("id"));

            dao.deleteProject(id);

            response.sendRedirect("project.jsp");
        }

        // EDIT

        else if(action.equals("edit")){

            int id =
                    Integer.parseInt(request.getParameter("id"));

            Project project =
                    dao.getProjectById(id);

            request.setAttribute("project", project);

            request.getRequestDispatcher("editProject.jsp")
                    .forward(request, response);
        }
    }
}