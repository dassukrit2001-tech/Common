package model;

public class Employee {

    private int empId;
    private String name;
    private String email;
    private String phone;
    private int deptId;
    private String role;
    private double salary;

    public Employee() {
    }

    public Employee(int empId, String name, String email, String phone,
                    int deptId, String role, double salary) {

        this.empId = empId;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.deptId = deptId;
        this.role = role;
        this.salary = salary;
    }

    public int getEmpId() {
        return empId;
    }

    public void setEmpId(int empId) {
        this.empId = empId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public int getDeptId() {
        return deptId;
    }

    public void setDeptId(int deptId) {
        this.deptId = deptId;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }
}