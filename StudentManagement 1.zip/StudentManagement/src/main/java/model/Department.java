package model;

public class Department {

    private int deptId;
    private String deptName;
    private int industryId;
    private String managerName;

    public Department() {
    }

    public Department(int deptId, String deptName, int industryId, String managerName) {
        this.deptId = deptId;
        this.deptName = deptName;
        this.industryId = industryId;
        this.managerName = managerName;
    }

    public int getDeptId() {
        return deptId;
    }

    public void setDeptId(int deptId) {
        this.deptId = deptId;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public int getIndustryId() {
        return industryId;
    }

    public void setIndustryId(int industryId) {
        this.industryId = industryId;
    }

    public String getManagerName() {
        return managerName;
    }

    public void setManagerName(String managerName) {
        this.managerName = managerName;
    }
}