package model;

public class Industry {

    private int industryId;
    private String industryName;
    private String location;
    private String type;

    public Industry() {
    }

    public Industry(int industryId, String industryName, String location, String type) {
        this.industryId = industryId;
        this.industryName = industryName;
        this.location = location;
        this.type = type;
    }

    public int getIndustryId() {
        return industryId;
    }

    public void setIndustryId(int industryId) {
        this.industryId = industryId;
    }

    public String getIndustryName() {
        return industryName;
    }

    public void setIndustryName(String industryName) {
        this.industryName = industryName;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}