package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import model.Industry;

public class IndustryDAO {

    Connection con = DBConnection.getConnection();

    // INSERT
    public boolean addIndustry(Industry i) {

        boolean status = false;

        try {

            String sql = "INSERT INTO industry(industry_name,location,type) VALUES(?,?,?)";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, i.getIndustryName());
            ps.setString(2, i.getLocation());
            ps.setString(3, i.getType());

            int row = ps.executeUpdate();

            if (row > 0) {
                status = true;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return status;
    }

    // VIEW
    public ArrayList<Industry> getAllIndustries() {

        ArrayList<Industry> list = new ArrayList<>();

        try {

            String sql = "SELECT * FROM industry";

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Industry i = new Industry();

                i.setIndustryId(rs.getInt("industry_id"));
                i.setIndustryName(rs.getString("industry_name"));
                i.setLocation(rs.getString("location"));
                i.setType(rs.getString("type"));

                list.add(i);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    // DELETE
    public boolean deleteIndustry(int id) {

        boolean status = false;

        try {

            String sql = "DELETE FROM industry WHERE industry_id=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, id);

            int row = ps.executeUpdate();

            if (row > 0) {
                status = true;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return status;
    }

    // GET BY ID
    public Industry getIndustryById(int id) {

        Industry i = null;

        try {

            String sql = "SELECT * FROM industry WHERE industry_id=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                i = new Industry();

                i.setIndustryId(rs.getInt("industry_id"));
                i.setIndustryName(rs.getString("industry_name"));
                i.setLocation(rs.getString("location"));
                i.setType(rs.getString("type"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return i;
    }

    // UPDATE
    public boolean updateIndustry(Industry i) {

        boolean status = false;

        try {

            String sql = "UPDATE industry SET industry_name=?, location=?, type=? WHERE industry_id=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, i.getIndustryName());
            ps.setString(2, i.getLocation());
            ps.setString(3, i.getType());
            ps.setInt(4, i.getIndustryId());

            int row = ps.executeUpdate();

            if (row > 0) {
                status = true;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return status;
    }
}