package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class DBConnection {

    private static Connection con;

    private static final String URL =
            "jdbc:mysql://localhost:3306/";

    private static final String DB_NAME =
            "industry_management";

    private static final String USER =
            "root";

    private static final String PASSWORD =
            "password";

    public static Connection getConnection() {

        try {

            // LOAD DRIVER

            Class.forName("com.mysql.cj.jdbc.Driver");

            // CONNECT MYSQL SERVER

            Connection tempCon =
                    DriverManager.getConnection(
                            URL,
                            USER,
                            PASSWORD);

            Statement stmt = tempCon.createStatement();

            // CREATE DATABASE

            String createDatabase =
                    "CREATE DATABASE IF NOT EXISTS "
                            + DB_NAME;

            stmt.executeUpdate(createDatabase);

            // CONNECT DATABASE

            con = DriverManager.getConnection(
                    URL + DB_NAME,
                    USER,
                    PASSWORD);

            Statement st = con.createStatement();

            // USERS TABLE

            String usersTable =
                    "CREATE TABLE IF NOT EXISTS users("
                            + "user_id INT PRIMARY KEY AUTO_INCREMENT,"
                            + "name VARCHAR(100),"
                            + "email VARCHAR(100) UNIQUE,"
                            + "password VARCHAR(100),"
                            + "role VARCHAR(20),"
                            + "phone VARCHAR(20)"
                            + ")";

            st.executeUpdate(usersTable);

            // INDUSTRY TABLE

            String industryTable =
                    "CREATE TABLE IF NOT EXISTS industry("
                            + "industry_id INT PRIMARY KEY AUTO_INCREMENT,"
                            + "industry_name VARCHAR(100),"
                            + "location VARCHAR(100),"
                            + "type VARCHAR(50)"
                            + ")";

            st.executeUpdate(industryTable);

            // DEPARTMENT TABLE

            String departmentTable =
                    "CREATE TABLE IF NOT EXISTS department("
                            + "dept_id INT PRIMARY KEY AUTO_INCREMENT,"
                            + "dept_name VARCHAR(100),"
                            + "industry_id INT,"
                            + "manager_name VARCHAR(100),"
                            + "FOREIGN KEY(industry_id)"
                            + " REFERENCES industry(industry_id)"
                            + " ON DELETE CASCADE"
                            + ")";

            st.executeUpdate(departmentTable);

            // EMPLOYEE TABLE

            String employeeTable =
                    "CREATE TABLE IF NOT EXISTS employee("
                            + "emp_id INT PRIMARY KEY AUTO_INCREMENT,"
                            + "name VARCHAR(100),"
                            + "email VARCHAR(100),"
                            + "phone VARCHAR(20),"
                            + "dept_id INT,"
                            + "role VARCHAR(50),"
                            + "salary DOUBLE,"
                            + "FOREIGN KEY(dept_id)"
                            + " REFERENCES department(dept_id)"
                            + " ON DELETE CASCADE"
                            + ")";

            st.executeUpdate(employeeTable);

            // PROJECT TABLE

            String projectTable =
                    "CREATE TABLE IF NOT EXISTS project("
                            + "project_id INT PRIMARY KEY AUTO_INCREMENT,"
                            + "project_name VARCHAR(100),"
                            + "start_date DATE,"
                            + "end_date DATE,"
                            + "dept_id INT,"
                            + "status VARCHAR(50),"
                            + "FOREIGN KEY(dept_id)"
                            + " REFERENCES department(dept_id)"
                            + " ON DELETE CASCADE"
                            + ")";

            st.executeUpdate(projectTable);

            System.out.println(
                    "Database and tables created successfully");

        } catch (Exception e) {

            e.printStackTrace();
        }

        return con;
    }
}