package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import model.Department;

public class DepartmentDAO {

    Connection con = DBConnection.getConnection();

    // ADD
    public boolean addDepartment(Department d) {

        boolean status = false;

        try {

            String sql = "INSERT INTO department(dept_name,industry_id,manager_name) VALUES(?,?,?)";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, d.getDeptName());
            ps.setInt(2, d.getIndustryId());
            ps.setString(3, d.getManagerName());

            int row = ps.executeUpdate();

            if (row > 0) {
                status = true;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return status;
    }

    // VIEW
    public ArrayList<Department> getAllDepartments() {

        ArrayList<Department> list = new ArrayList<>();

        try {

            String sql = "SELECT * FROM department";

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Department d = new Department();

                d.setDeptId(rs.getInt("dept_id"));
                d.setDeptName(rs.getString("dept_name"));
                d.setIndustryId(rs.getInt("industry_id"));
                d.setManagerName(rs.getString("manager_name"));

                list.add(d);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    // DELETE
    public boolean deleteDepartment(int id) {

        boolean status = false;

        try {

            String sql = "DELETE FROM department WHERE dept_id=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, id);

            int row = ps.executeUpdate();

            if (row > 0) {
                status = true;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return status;
    }

    // GET BY ID
    public Department getDepartmentById(int id) {

        Department d = null;

        try {

            String sql = "SELECT * FROM department WHERE dept_id=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                d = new Department();

                d.setDeptId(rs.getInt("dept_id"));
                d.setDeptName(rs.getString("dept_name"));
                d.setIndustryId(rs.getInt("industry_id"));
                d.setManagerName(rs.getString("manager_name"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return d;
    }

    // UPDATE
    public boolean updateDepartment(Department d) {

        boolean status = false;

        try {

            String sql = "UPDATE department SET dept_name=?, industry_id=?, manager_name=? WHERE dept_id=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, d.getDeptName());
            ps.setInt(2, d.getIndustryId());
            ps.setString(3, d.getManagerName());
            ps.setInt(4, d.getDeptId());

            int row = ps.executeUpdate();

            if (row > 0) {
                status = true;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return status;
    }
}