package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import model.Project;

public class ProjectDAO {

    Connection con = DBConnection.getConnection();

    public boolean addProject(Project p) {

        boolean status = false;

        try {

            String sql = "INSERT INTO project(project_name,start_date,end_date,dept_id,status) VALUES(?,?,?,?,?)";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, p.getProjectName());
            ps.setDate(2, p.getStartDate());
            ps.setDate(3, p.getEndDate());
            ps.setInt(4, p.getDeptId());
            ps.setString(5, p.getStatus());

            int row = ps.executeUpdate();

            if (row > 0) {
                status = true;
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return status;
    }

    public ArrayList<Project> getAllProjects() {

        ArrayList<Project> list = new ArrayList<>();

        try {

            String sql = "SELECT * FROM project";

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Project p = new Project();

                p.setProjectId(rs.getInt("project_id"));
                p.setProjectName(rs.getString("project_name"));
                p.setStartDate(rs.getDate("start_date"));
                p.setEndDate(rs.getDate("end_date"));
                p.setDeptId(rs.getInt("dept_id"));
                p.setStatus(rs.getString("status"));

                list.add(p);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return list;
    }

    public boolean deleteProject(int id) {

        boolean status = false;

        try {

            String sql = "DELETE FROM project WHERE project_id=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, id);

            int row = ps.executeUpdate();

            if (row > 0) {
                status = true;
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return status;
    }

    public Project getProjectById(int id) {

        Project p = null;

        try {

            String sql = "SELECT * FROM project WHERE project_id=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                p = new Project();

                p.setProjectId(rs.getInt("project_id"));
                p.setProjectName(rs.getString("project_name"));
                p.setStartDate(rs.getDate("start_date"));
                p.setEndDate(rs.getDate("end_date"));
                p.setDeptId(rs.getInt("dept_id"));
                p.setStatus(rs.getString("status"));
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return p;
    }

    public boolean updateProject(Project p) {

        boolean status = false;

        try {

            String sql = "UPDATE project SET project_name=?,start_date=?,end_date=?,dept_id=?,status=? WHERE project_id=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, p.getProjectName());
            ps.setDate(2, p.getStartDate());
            ps.setDate(3, p.getEndDate());
            ps.setInt(4, p.getDeptId());
            ps.setString(5, p.getStatus());
            ps.setInt(6, p.getProjectId());

            int row = ps.executeUpdate();

            if (row > 0) {
                status = true;
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return status;
    }
}