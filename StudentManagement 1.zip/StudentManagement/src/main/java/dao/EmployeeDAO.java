package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import model.Employee;

public class EmployeeDAO {

    Connection con = DBConnection.getConnection();

    public boolean addEmployee(Employee e) {

        boolean status = false;

        try {

            String sql = "INSERT INTO employee(name,email,phone,dept_id,role,salary) VALUES(?,?,?,?,?,?)";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, e.getName());
            ps.setString(2, e.getEmail());
            ps.setString(3, e.getPhone());
            ps.setInt(4, e.getDeptId());
            ps.setString(5, e.getRole());
            ps.setDouble(6, e.getSalary());

            int row = ps.executeUpdate();

            if (row > 0) {
                status = true;
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return status;
    }

    public ArrayList<Employee> getAllEmployees() {

        ArrayList<Employee> list = new ArrayList<>();

        try {

            String sql = "SELECT * FROM employee";

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Employee e = new Employee();

                e.setEmpId(rs.getInt("emp_id"));
                e.setName(rs.getString("name"));
                e.setEmail(rs.getString("email"));
                e.setPhone(rs.getString("phone"));
                e.setDeptId(rs.getInt("dept_id"));
                e.setRole(rs.getString("role"));
                e.setSalary(rs.getDouble("salary"));

                list.add(e);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return list;
    }

    public boolean deleteEmployee(int id) {

        boolean status = false;

        try {

            String sql = "DELETE FROM employee WHERE emp_id=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, id);

            int row = ps.executeUpdate();

            if (row > 0) {
                status = true;
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return status;
    }

    public Employee getEmployeeById(int id) {

        Employee e = null;

        try {

            String sql = "SELECT * FROM employee WHERE emp_id=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                e = new Employee();

                e.setEmpId(rs.getInt("emp_id"));
                e.setName(rs.getString("name"));
                e.setEmail(rs.getString("email"));
                e.setPhone(rs.getString("phone"));
                e.setDeptId(rs.getInt("dept_id"));
                e.setRole(rs.getString("role"));
                e.setSalary(rs.getDouble("salary"));
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return e;
    }

    public boolean updateEmployee(Employee e) {

        boolean status = false;

        try {

            String sql = "UPDATE employee SET name=?,email=?,phone=?,dept_id=?,role=?,salary=? WHERE emp_id=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, e.getName());
            ps.setString(2, e.getEmail());
            ps.setString(3, e.getPhone());
            ps.setInt(4, e.getDeptId());
            ps.setString(5, e.getRole());
            ps.setDouble(6, e.getSalary());
            ps.setInt(7, e.getEmpId());

            int row = ps.executeUpdate();

            if (row > 0) {
                status = true;
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return status;
    }
}