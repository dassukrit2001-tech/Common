<%@page import="java.util.ArrayList"%>
<%@page import="dao.DepartmentDAO"%>
<%@page import="dao.IndustryDAO"%>
<%@page import="model.Department"%>
<%@page import="model.Industry"%>

<%
if(session.getAttribute("user")==null){

    response.sendRedirect("login.jsp");
    return;
}

String role = (String)session.getAttribute("role");
%>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">
<title>Department Management</title>

<link rel="stylesheet" href="css/style.css">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family: Arial, sans-serif;
    background:#f1f5f9;
}

/* Navbar */

.navbar{
    width:100%;
    background:#0f172a;
    padding:18px 40px;
    display:flex;
    justify-content:space-between;
    align-items:center;
}

.logo{
    color:white;
    font-size:24px;
    font-weight:bold;
}

.nav-links a{
    color:white;
    text-decoration:none;
    margin-left:20px;
    font-size:16px;
    transition:0.3s;
}

.nav-links a:hover{
    color:#38bdf8;
}

/* Main Container */

.container{
    width:90%;
    margin:30px auto;
}

/* Heading */

.page-header{
    margin-bottom:25px;
}

.page-header h1{
    color:#0f172a;
    margin-bottom:8px;
}

.page-header p{
    color:gray;
}

/* Form Card */

.form-card{
    background:white;
    padding:25px;
    border-radius:15px;
    box-shadow:0 4px 15px rgba(0,0,0,0.08);
    margin-bottom:30px;
}

.form-card h2{
    margin-bottom:20px;
    color:#0f172a;
}

.form-group{
    margin-bottom:18px;
}

.form-group label{
    display:block;
    margin-bottom:8px;
    font-weight:bold;
    color:#334155;
}

.form-group input,
.form-group select{
    width:100%;
    padding:12px;
    border:1px solid #cbd5e1;
    border-radius:8px;
    font-size:15px;
}

.submit-btn{
    background:#2563eb;
    color:white;
    border:none;
    padding:12px 20px;
    border-radius:8px;
    cursor:pointer;
    font-size:16px;
    transition:0.3s;
}

.submit-btn:hover{
    background:#1d4ed8;
}

/* Table */

.table-card{
    background:white;
    padding:25px;
    border-radius:15px;
    box-shadow:0 4px 15px rgba(0,0,0,0.08);
}

.table-card h2{
    margin-bottom:20px;
    color:#0f172a;
}

table{
    width:100%;
    border-collapse:collapse;
}

table th{
    background:#2563eb;
    color:white;
    padding:14px;
    text-align:left;
}

table td{
    padding:14px;
    border-bottom:1px solid #e2e8f0;
}

table tr:hover{
    background:#f8fafc;
}

/* Buttons */

.edit-btn{
    text-decoration:none;
    background:#22c55e;
    color:white;
    padding:8px 12px;
    border-radius:6px;
    margin-right:5px;
    transition:0.3s;
}

.edit-btn:hover{
    background:#16a34a;
}

.delete-btn{
    text-decoration:none;
    background:#ef4444;
    color:white;
    padding:8px 12px;
    border-radius:6px;
    transition:0.3s;
}

.delete-btn:hover{
    background:#dc2626;
}

/* Role Badge */

.role-badge{
    display:inline-block;
    background:#dbeafe;
    color:#1d4ed8;
    padding:6px 14px;
    border-radius:20px;
    font-size:14px;
    margin-top:8px;
}

</style>

</head>

<body>

<!-- Navbar -->

<div class="navbar">

<div class="logo">
Department Panel
</div>

<div class="nav-links">

<%
if(role.equals("Admin")){
%>

<a href="adminDashboard.jsp">Dashboard</a>

<%
}else{
%>

<a href="employeeDashboard.jsp">Dashboard</a>

<%
}
%>

<a href="LogoutServlet">Logout</a>

</div>

</div>

<!-- Main Content -->

<div class="container">

<div class="page-header">

<h1>Department Management</h1>

<p>
Manage department records and organization structure.
</p>

<div class="role-badge">
Logged in as : <%= role %>
</div>

</div>

<%
if(role.equals("Admin")){
%>

<!-- Add Department Form -->

<div class="form-card">

<h2>Add New Department</h2>

<form action="DepartmentServlet" method="post">

<input type="hidden" name="action" value="add">

<div class="form-group">

<label>Department Name</label>

<input type="text" name="deptName" required>

</div>

<div class="form-group">

<label>Select Industry</label>

<select name="industryId">

<%
IndustryDAO industryDAO = new IndustryDAO();

ArrayList<Industry> industries =
industryDAO.getAllIndustries();

for(Industry ind : industries){
%>

<option value="<%= ind.getIndustryId() %>">

<%= ind.getIndustryName() %>

</option>

<%
}
%>

</select>

</div>

<div class="form-group">

<label>Manager Name</label>

<input type="text" name="managerName" required>

</div>

<input type="submit"
value="Add Department"
class="submit-btn">

</form>

</div>

<%
}
%>

<!-- Department Table -->

<div class="table-card">

<h2>Department List</h2>

<table>

<tr>

<th>ID</th>
<th>Department Name</th>
<th>Industry ID</th>
<th>Manager</th>

<%
if(role.equals("Admin")){
%>

<th>Actions</th>

<%
}
%>

</tr>

<%
DepartmentDAO dao = new DepartmentDAO();

ArrayList<Department> list =
dao.getAllDepartments();

for(Department d : list){
%>

<tr>

<td><%= d.getDeptId() %></td>

<td><%= d.getDeptName() %></td>

<td><%= d.getIndustryId() %></td>

<td><%= d.getManagerName() %></td>

<%
if(role.equals("Admin")){
%>

<td>

<a class="edit-btn"
href="DepartmentServlet?action=edit&id=<%= d.getDeptId() %>">

Edit

</a>

<a class="delete-btn"
href="DepartmentServlet?action=delete&id=<%= d.getDeptId() %>">

Delete

</a>

</td>

<%
}
%>

</tr>

<%
}
%>

</table>

</div>

</div>

</body>
</html>