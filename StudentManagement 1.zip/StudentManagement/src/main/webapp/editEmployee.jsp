<%
if(session.getAttribute("user")==null){

    response.sendRedirect("login.jsp");
    return;
}

String role = (String)session.getAttribute("role");

if(!role.equals("Admin")){

    response.sendRedirect("employeeDashboard.jsp");
    return;
}
%>

<%@page import="model.Employee"%>

<%
Employee e =
(Employee)request.getAttribute("employee");
%>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">
<title>Edit Employee</title>

<link rel="stylesheet" href="css/style.css">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family: Arial, sans-serif;
    background: linear-gradient(to right, #dbeafe, #f8fafc);
    min-height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    padding:20px;
}

/* Main Container */

.edit-card{
    width:650px;
    background:white;
    border-radius:20px;
    padding:35px;
    box-shadow:0 10px 30px rgba(0,0,0,0.12);
}

/* Header */

.header{
    text-align:center;
    margin-bottom:30px;
}

.header h2{
    color:#0f172a;
    font-size:32px;
    margin-bottom:10px;
}

.header p{
    color:gray;
    font-size:15px;
}

.emp-badge{
    display:inline-block;
    margin-top:12px;
    background:#dbeafe;
    color:#1d4ed8;
    padding:7px 15px;
    border-radius:25px;
    font-size:14px;
    font-weight:bold;
}

/* Form Layout */

.form-grid{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:20px;
}

.form-group{
    display:flex;
    flex-direction:column;
}

.form-group label{
    margin-bottom:8px;
    font-weight:bold;
    color:#334155;
}

.form-group input{
    padding:12px;
    border:1px solid #cbd5e1;
    border-radius:10px;
    font-size:15px;
    transition:0.3s;
}

.form-group input:focus{
    border-color:#2563eb;
    outline:none;
    box-shadow:0 0 6px rgba(37,99,235,0.3);
}

/* Full Width Fields */

.full-width{
    grid-column:1 / 3;
}

/* Buttons */

.button-group{
    margin-top:30px;
    display:flex;
    justify-content:space-between;
}

.update-btn{
    background:#2563eb;
    color:white;
    border:none;
    padding:13px 24px;
    border-radius:10px;
    font-size:16px;
    cursor:pointer;
    transition:0.3s;
}

.update-btn:hover{
    background:#1d4ed8;
}

.back-btn{
    background:#64748b;
    color:white;
    text-decoration:none;
    padding:13px 24px;
    border-radius:10px;
    transition:0.3s;
}

.back-btn:hover{
    background:#475569;
}

/* Responsive */

@media(max-width:700px){

    .form-grid{
        grid-template-columns:1fr;
    }

    .full-width{
        grid-column:auto;
    }

    .edit-card{
        width:100%;
    }
}

</style>

</head>

<body>

<div class="edit-card">

<!-- Header -->

<div class="header">

<h2>Edit Employee</h2>

<p>
Update employee details and information
</p>

<div class="emp-badge">

Employee ID :
<%= e.getEmpId() %>

</div>

</div>

<!-- Form -->

<form action="EmployeeServlet" method="post">

<input type="hidden" name="action" value="update">

<input type="hidden"
name="empId"
value="<%= e.getEmpId() %>">

<div class="form-grid">

<div class="form-group">

<label>Employee Name</label>

<input type="text"
name="name"
value="<%= e.getName() %>"
required>

</div>

<div class="form-group">

<label>Email Address</label>

<input type="email"
name="email"
value="<%= e.getEmail() %>"
required>

</div>

<div class="form-group">

<label>Phone Number</label>

<input type="text"
name="phone"
value="<%= e.getPhone() %>"
required>

</div>

<div class="form-group">

<label>Department ID</label>

<input type="text"
name="deptId"
value="<%= e.getDeptId() %>"
required>

</div>

<div class="form-group">

<label>Role</label>

<input type="text"
name="role"
value="<%= e.getRole() %>"
required>

</div>

<div class="form-group">

<label>Salary</label>

<input type="number"
step="0.01"
name="salary"
value="<%= e.getSalary() %>"
required>

</div>

</div>

<!-- Buttons -->

<div class="button-group">

<a href="employee.jsp" class="back-btn">

Back

</a>

<input type="submit"
value="Update Employee"
class="update-btn">

</div>

</form>

</div>

</body>
</html>