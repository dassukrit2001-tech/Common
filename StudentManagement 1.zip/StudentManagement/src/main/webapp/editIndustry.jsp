<%
if(session.getAttribute("user")==null){

    response.sendRedirect("login.jsp");
    return;
}

String role = (String)session.getAttribute("role");

if(!role.equals("Admin")){

    response.sendRedirect("employeeDashboard.jsp");
    return;
}
%>

<%@page import="model.Industry"%>

<%
Industry i = (Industry)request.getAttribute("industry");
%>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">
<title>Edit Industry</title>

<link rel="stylesheet" href="css/style.css">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family: Arial, sans-serif;
    background: linear-gradient(to right, #e0f2fe, #f8fafc);
    min-height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    padding:20px;
}

/* Main Card */

.edit-card{
    width:550px;
    background:white;
    padding:35px;
    border-radius:20px;
    box-shadow:0 10px 30px rgba(0,0,0,0.12);
}

/* Header */

.header{
    text-align:center;
    margin-bottom:30px;
}

.header h2{
    color:#0f172a;
    font-size:32px;
    margin-bottom:10px;
}

.header p{
    color:gray;
    font-size:15px;
}

.industry-badge{
    display:inline-block;
    margin-top:12px;
    background:#dbeafe;
    color:#1d4ed8;
    padding:7px 16px;
    border-radius:25px;
    font-size:14px;
    font-weight:bold;
}

/* Form */

.form-group{
    margin-bottom:22px;
}

.form-group label{
    display:block;
    margin-bottom:8px;
    font-weight:bold;
    color:#334155;
}

.form-group input{
    width:100%;
    padding:13px;
    border:1px solid #cbd5e1;
    border-radius:10px;
    font-size:15px;
    transition:0.3s;
}

.form-group input:focus{
    border-color:#2563eb;
    outline:none;
    box-shadow:0 0 6px rgba(37,99,235,0.3);
}

/* Buttons */

.button-group{
    margin-top:30px;
    display:flex;
    justify-content:space-between;
}

.update-btn{
    background:#2563eb;
    color:white;
    border:none;
    padding:13px 24px;
    border-radius:10px;
    font-size:16px;
    cursor:pointer;
    transition:0.3s;
}

.update-btn:hover{
    background:#1d4ed8;
}

.back-btn{
    background:#64748b;
    color:white;
    text-decoration:none;
    padding:13px 24px;
    border-radius:10px;
    transition:0.3s;
}

.back-btn:hover{
    background:#475569;
}

/* Responsive */

@media(max-width:600px){

    .edit-card{
        width:100%;
        padding:25px;
    }

    .button-group{
        flex-direction:column;
        gap:15px;
    }

    .update-btn,
    .back-btn{
        width:100%;
        text-align:center;
    }
}

</style>

</head>

<body>

<div class="edit-card">

<!-- Header -->

<div class="header">

<h2>Edit Industry</h2>

<p>
Update industry information and details
</p>

<div class="industry-badge">

Industry ID :
<%= i.getIndustryId() %>

</div>

</div>

<!-- Form -->

<form action="IndustryServlet" method="post">

<input type="hidden" name="action" value="update">

<input type="hidden"
name="industryId"
value="<%= i.getIndustryId() %>">

<div class="form-group">

<label>Industry Name</label>

<input type="text"
name="industryName"
value="<%= i.getIndustryName() %>"
required>

</div>

<div class="form-group">

<label>Location</label>

<input type="text"
name="location"
value="<%= i.getLocation() %>"
required>

</div>

<div class="form-group">

<label>Industry Type</label>

<input type="text"
name="type"
value="<%= i.getType() %>"
required>

</div>

<!-- Buttons -->

<div class="button-group">

<a href="industry.jsp" class="back-btn">

Back

</a>

<input type="submit"
value="Update Industry"
class="update-btn">

</div>

</form>

</div>

</body>
</html>