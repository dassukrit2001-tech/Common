<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">
<title>Register</title>

<link rel="stylesheet" href="css/style.css">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family: Arial, sans-serif;
    min-height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background: linear-gradient(to right, #0f172a, #1e3a8a);
    padding:20px;
}

/* Register Box */

.auth-box{
    width:500px;
    background:white;
    padding:40px;
    border-radius:20px;
    box-shadow:0 10px 30px rgba(0,0,0,0.2);
}

/* Logo */

.logo{
    width:85px;
    height:85px;
    background:#2563eb;
    color:white;
    margin:auto;
    border-radius:50%;
    display:flex;
    justify-content:center;
    align-items:center;
    font-size:32px;
    font-weight:bold;
    margin-bottom:20px;
}

/* Heading */

.auth-box h2{
    text-align:center;
    color:#0f172a;
    margin-bottom:10px;
    font-size:32px;
}

.subtitle{
    text-align:center;
    color:gray;
    margin-bottom:30px;
    font-size:15px;
}

/* Messages */

.error{
    background:#fee2e2;
    color:#991b1b;
    padding:12px;
    border-radius:8px;
    margin-bottom:18px;
    text-align:center;
    font-size:14px;
}

/* Form */

form{
    display:flex;
    flex-direction:column;
}

.form-grid{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:18px;
}

.form-group{
    display:flex;
    flex-direction:column;
}

.full-width{
    grid-column:1 / 3;
}

label{
    margin-bottom:8px;
    font-weight:bold;
    color:#334155;
}

input,
select{
    padding:13px;
    border:1px solid #cbd5e1;
    border-radius:10px;
    font-size:15px;
    transition:0.3s;
}

input:focus,
select:focus{
    border-color:#2563eb;
    outline:none;
    box-shadow:0 0 6px rgba(37,99,235,0.3);
}

/* Button */

.submit-btn{
    margin-top:25px;
    background:#2563eb;
    color:white;
    border:none;
    padding:14px;
    border-radius:10px;
    cursor:pointer;
    font-size:16px;
    font-weight:bold;
    transition:0.3s;
}

.submit-btn:hover{
    background:#1d4ed8;
    transform:translateY(-2px);
}

/* Login Link */

.login-link{
    margin-top:22px;
    text-align:center;
}

.login-link a{
    color:#2563eb;
    text-decoration:none;
    font-weight:bold;
}

.login-link a:hover{
    text-decoration:underline;
}

/* Responsive */

@media(max-width:600px){

    .auth-box{
        width:100%;
        padding:30px;
    }

    .form-grid{
        grid-template-columns:1fr;
    }

    .full-width{
        grid-column:auto;
    }
}

</style>

</head>

<body>

<div class="auth-box">

<!-- Logo -->

<div class="logo">

IMS

</div>

<!-- Heading -->

<h2>Create Account</h2>

<p class="subtitle">

Register to access the Industry Management System

</p>

<!-- Messages -->

<%
String msg = request.getParameter("msg");

if("PasswordMismatch".equals(msg)){
%>

<div class="error">

Passwords do not match

</div>

<%
}

if("Failed".equals(msg)){
%>

<div class="error">

Registration Failed

</div>

<%
}
%>

<!-- Registration Form -->

<form action="RegisterServlet" method="post">

<div class="form-grid">

<div class="form-group full-width">

<label>Full Name</label>

<input type="text"
name="name"
placeholder="Enter your full name"
required>

</div>

<div class="form-group">

<label>Email Address</label>

<input type="email"
name="email"
placeholder="Enter email"
required>

</div>

<div class="form-group">

<label>Phone Number</label>

<input type="text"
name="phone"
placeholder="Enter phone number"
required>

</div>

<div class="form-group">

<label>Password</label>

<input type="password"
name="password"
placeholder="Enter password"
required>

</div>

<div class="form-group">

<label>Confirm Password</label>

<input type="password"
name="confirmPassword"
placeholder="Confirm password"
required>

</div>

<div class="form-group full-width">

<label>Select Role</label>

<select name="role">

<option value="Admin">Admin</option>

<option value="Employee">Employee</option>

</select>

</div>

</div>

<input type="submit"
value="Register"
class="submit-btn">

</form>

<!-- Login -->

<div class="login-link">

Already have an account?

<a href="login.jsp">

Login

</a>

</div>

</div>

</body>
</html>