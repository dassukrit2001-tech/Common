<%
if(session.getAttribute("user")==null){

    response.sendRedirect("login.jsp");
    return;
}

String role = (String)session.getAttribute("role");

if(!role.equals("Admin")){

    response.sendRedirect("employeeDashboard.jsp");
    return;
}
%>

<%@page import="model.Project"%>

<%
Project p =
(Project)request.getAttribute("project");
%>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">
<title>Edit Project</title>

<link rel="stylesheet" href="css/style.css">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family: Arial, sans-serif;
    background: linear-gradient(to right, #dbeafe, #f8fafc);
    min-height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    padding:20px;
}

/* Main Card */

.edit-card{
    width:650px;
    background:white;
    padding:35px;
    border-radius:20px;
    box-shadow:0 10px 30px rgba(0,0,0,0.12);
}

/* Header */

.header{
    text-align:center;
    margin-bottom:30px;
}

.header h2{
    font-size:32px;
    color:#0f172a;
    margin-bottom:10px;
}

.header p{
    color:gray;
    font-size:15px;
}

.project-badge{
    display:inline-block;
    margin-top:12px;
    background:#dbeafe;
    color:#1d4ed8;
    padding:7px 16px;
    border-radius:25px;
    font-size:14px;
    font-weight:bold;
}

/* Form Grid */

.form-grid{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:20px;
}

.form-group{
    display:flex;
    flex-direction:column;
}

.form-group label{
    margin-bottom:8px;
    font-weight:bold;
    color:#334155;
}

.form-group input{
    padding:13px;
    border:1px solid #cbd5e1;
    border-radius:10px;
    font-size:15px;
    transition:0.3s;
}

.form-group input:focus{
    border-color:#2563eb;
    outline:none;
    box-shadow:0 0 6px rgba(37,99,235,0.3);
}

/* Full Width */

.full-width{
    grid-column:1 / 3;
}

/* Buttons */

.button-group{
    margin-top:30px;
    display:flex;
    justify-content:space-between;
}

.update-btn{
    background:#2563eb;
    color:white;
    border:none;
    padding:13px 24px;
    border-radius:10px;
    font-size:16px;
    cursor:pointer;
    transition:0.3s;
}

.update-btn:hover{
    background:#1d4ed8;
}

.back-btn{
    background:#64748b;
    color:white;
    text-decoration:none;
    padding:13px 24px;
    border-radius:10px;
    transition:0.3s;
}

.back-btn:hover{
    background:#475569;
}

/* Responsive */

@media(max-width:700px){

    .form-grid{
        grid-template-columns:1fr;
    }

    .full-width{
        grid-column:auto;
    }

    .edit-card{
        width:100%;
        padding:25px;
    }

    .button-group{
        flex-direction:column;
        gap:15px;
    }

    .update-btn,
    .back-btn{
        width:100%;
        text-align:center;
    }
}

</style>

</head>

<body>

<div class="edit-card">

<!-- Header -->

<div class="header">

<h2>Edit Project</h2>

<p>
Modify project information and tracking details
</p>

<div class="project-badge">

Project ID :
<%= p.getProjectId() %>

</div>

</div>

<!-- Form -->

<form action="ProjectServlet" method="post">

<input type="hidden" name="action" value="update">

<input type="hidden"
name="projectId"
value="<%= p.getProjectId() %>">

<div class="form-grid">

<div class="form-group full-width">

<label>Project Name</label>

<input type="text"
name="projectName"
value="<%= p.getProjectName() %>"
required>

</div>

<div class="form-group">

<label>Start Date</label>

<input type="date"
name="startDate"
value="<%= p.getStartDate() %>"
required>

</div>

<div class="form-group">

<label>End Date</label>

<input type="date"
name="endDate"
value="<%= p.getEndDate() %>"
required>

</div>

<div class="form-group">

<label>Department ID</label>

<input type="text"
name="deptId"
value="<%= p.getDeptId() %>"
required>

</div>

<div class="form-group">

<label>Project Status</label>

<input type="text"
name="status"
value="<%= p.getStatus() %>"
required>

</div>

</div>

<!-- Buttons -->

<div class="button-group">

<a href="project.jsp" class="back-btn">

Back

</a>

<input type="submit"
value="Update Project"
class="update-btn">

</div>

</form>

</div>

</body>
</html>