<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">
<title>Login</title>

<link rel="stylesheet" href="css/style.css">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family: Arial, sans-serif;
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background: linear-gradient(to right, #0f172a, #1e3a8a);
}

/* Login Box */

.auth-box{
    width:420px;
    background:white;
    padding:40px;
    border-radius:20px;
    box-shadow:0 10px 30px rgba(0,0,0,0.2);
}

/* Logo */

.logo{
    width:85px;
    height:85px;
    background:#2563eb;
    color:white;
    margin:auto;
    border-radius:50%;
    display:flex;
    justify-content:center;
    align-items:center;
    font-size:32px;
    font-weight:bold;
    margin-bottom:20px;
}

/* Heading */

.auth-box h2{
    text-align:center;
    color:#0f172a;
    margin-bottom:10px;
    font-size:32px;
}

.subtitle{
    text-align:center;
    color:gray;
    margin-bottom:30px;
    font-size:15px;
}

/* Alerts */

.success{
    background:#dcfce7;
    color:#166534;
    padding:12px;
    border-radius:8px;
    margin-bottom:18px;
    text-align:center;
    font-size:14px;
}

.error{
    background:#fee2e2;
    color:#991b1b;
    padding:12px;
    border-radius:8px;
    margin-bottom:18px;
    text-align:center;
    font-size:14px;
}

/* Form */

form{
    display:flex;
    flex-direction:column;
}

label{
    margin-bottom:8px;
    margin-top:10px;
    font-weight:bold;
    color:#334155;
}

input{
    padding:13px;
    border:1px solid #cbd5e1;
    border-radius:10px;
    font-size:15px;
    transition:0.3s;
}

input:focus{
    border-color:#2563eb;
    outline:none;
    box-shadow:0 0 6px rgba(37,99,235,0.3);
}

/* Button */

.submit-btn{
    margin-top:25px;
    background:#2563eb;
    color:white;
    border:none;
    padding:14px;
    border-radius:10px;
    cursor:pointer;
    font-size:16px;
    font-weight:bold;
    transition:0.3s;
}

.submit-btn:hover{
    background:#1d4ed8;
    transform:translateY(-2px);
}

/* Register Link */

.register-link{
    margin-top:22px;
    text-align:center;
}

.register-link a{
    color:#2563eb;
    text-decoration:none;
    font-weight:bold;
}

.register-link a:hover{
    text-decoration:underline;
}

/* Responsive */

@media(max-width:500px){

    .auth-box{
        width:90%;
        padding:30px;
    }
}

</style>

</head>

<body>

<div class="auth-box">

<!-- Logo -->

<div class="logo">

IMS

</div>

<!-- Heading -->

<h2>Login</h2>

<p class="subtitle">

Sign in to continue to the Industry Management System

</p>

<!-- Messages -->

<%
String msg = request.getParameter("msg");

if("Registered".equals(msg)){
%>

<div class="success">

Registration Successful

</div>

<%
}

if("Invalid".equals(msg)){
%>

<div class="error">

Invalid Email or Password

</div>

<%
}
%>

<!-- Login Form -->

<form action="LoginServlet" method="post">

<label>Email Address</label>

<input type="email"
name="email"
placeholder="Enter your email"
required>

<label>Password</label>

<input type="password"
name="password"
placeholder="Enter your password"
required>

<input type="submit"
value="Login"
class="submit-btn">

</form>

<!-- Register -->

<div class="register-link">

Don't have an account?

<a href="register.jsp">

Create Account

</a>

</div>

</div>

</body>
</html>