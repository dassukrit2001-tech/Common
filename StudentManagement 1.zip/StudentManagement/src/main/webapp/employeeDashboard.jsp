<%
if(session.getAttribute("user")==null){

    response.sendRedirect("login.jsp");
    return;
}

String role = (String)session.getAttribute("role");

if(!role.equals("Employee")){

    response.sendRedirect("adminDashboard.jsp");
    return;
}
%>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">
<title>Employee Dashboard</title>

<link rel="stylesheet" href="css/style.css">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family: Arial, sans-serif;
    background:#f1f5f9;
}

/* Sidebar */

.sidebar{
    width:250px;
    height:100vh;
    background:#0f172a;
    position:fixed;
    left:0;
    top:0;
    padding-top:25px;
}

.sidebar h2{
    color:white;
    text-align:center;
    margin-bottom:40px;
    font-size:28px;
}

.sidebar a{
    display:block;
    color:#cbd5e1;
    text-decoration:none;
    padding:15px 25px;
    font-size:16px;
    transition:0.3s;
}

.sidebar a:hover{
    background:#1e293b;
    color:white;
    padding-left:35px;
}

/* Main Section */

.main{
    margin-left:250px;
    padding:30px;
}

/* Topbar */

.topbar{
    background:white;
    padding:25px;
    border-radius:18px;
    box-shadow:0 5px 15px rgba(0,0,0,0.08);
    margin-bottom:30px;
}

.topbar h1{
    color:#0f172a;
    margin-bottom:10px;
}

.topbar p{
    color:gray;
    font-size:16px;
}

.user-badge{
    display:inline-block;
    margin-top:12px;
    background:#dbeafe;
    color:#1d4ed8;
    padding:7px 16px;
    border-radius:25px;
    font-size:14px;
    font-weight:bold;
}

/* Dashboard Cards */

.card-container{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
    gap:20px;
    margin-bottom:30px;
}

.card{
    background:white;
    padding:25px;
    border-radius:18px;
    box-shadow:0 5px 15px rgba(0,0,0,0.08);
    transition:0.3s;
}

.card:hover{
    transform:translateY(-5px);
}

.card h2{
    color:#0f172a;
    margin-bottom:12px;
}

.card p{
    color:gray;
    margin-bottom:20px;
    line-height:1.5;
}

.card a{
    display:inline-block;
    text-decoration:none;
    background:#2563eb;
    color:white;
    padding:10px 18px;
    border-radius:8px;
    transition:0.3s;
}

.card a:hover{
    background:#1d4ed8;
}

/* Permission Box */

.permission-box{
    background:white;
    padding:25px;
    border-radius:18px;
    box-shadow:0 5px 15px rgba(0,0,0,0.08);
}

.permission-box h2{
    color:#0f172a;
    margin-bottom:20px;
}

.permission-box ul{
    list-style:none;
}

.permission-box ul li{
    background:#eff6ff;
    margin-bottom:12px;
    padding:12px;
    border-left:5px solid #2563eb;
    border-radius:6px;
    color:#334155;
}

/* Responsive */

@media(max-width:768px){

    .sidebar{
        width:100%;
        height:auto;
        position:relative;
    }

    .main{
        margin-left:0;
    }
}

</style>

</head>

<body>

<!-- Sidebar -->

<div class="sidebar">

<h2>Employee Panel</h2>

<a href="employeeDashboard.jsp">Dashboard</a>

<a href="industry.jsp">Industry</a>

<a href="department.jsp">Department</a>

<a href="employee.jsp">Employee</a>

<a href="project.jsp">Project</a>

<a href="LogoutServlet">Logout</a>

</div>

<!-- Main Content -->

<div class="main">

<!-- Topbar -->

<div class="topbar">

<h1>Employee Dashboard</h1>

<p>
Welcome back,
<b><%= session.getAttribute("name") %></b>
</p>

<div class="user-badge">

Employee Access Panel

</div>

</div>

<!-- Feature Cards -->

<div class="card-container">

<div class="card">

<h2>Industry Records</h2>

<p>
View all industry information and organization details.
</p>

<a href="industry.jsp">

View Industry

</a>

</div>

<div class="card">

<h2>Department Records</h2>

<p>
Access department information and manager details.
</p>

<a href="department.jsp">

View Department

</a>

</div>

<div class="card">

<h2>Employee Records</h2>

<p>
View employee details and department assignments.
</p>

<a href="employee.jsp">

View Employee

</a>

</div>

<div class="card">

<h2>Project Records</h2>

<p>
Check project status, timelines and assigned departments.
</p>

<a href="project.jsp">

View Project

</a>

</div>

</div>

<!-- Permission Section -->

<div class="permission-box">

<h2>Employee Permissions</h2>

<ul>

<li>View Industry Records</li>

<li>View Department Records</li>

<li>View Employee Records</li>

<li>View Project Records</li>

<li>No Add / Edit / Delete Access</li>

<li>Read Only Access to System Modules</li>

</ul>

</div>

</div>

</body>
</html>