<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">

<title>Industry Management System</title>

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family: Arial, sans-serif;
    height:100vh;
    background: linear-gradient(to right, #0f172a, #1e3a8a);
    display:flex;
    justify-content:center;
    align-items:center;
}

/* Main Card */

.home-container{
    width:450px;
    background:white;
    padding:40px;
    border-radius:20px;
    text-align:center;
    box-shadow:0 10px 30px rgba(0,0,0,0.2);
}

/* Logo Circle */

.logo{
    width:90px;
    height:90px;
    background:#2563eb;
    color:white;
    margin:auto;
    border-radius:50%;
    display:flex;
    justify-content:center;
    align-items:center;
    font-size:36px;
    font-weight:bold;
    margin-bottom:20px;
}

/* Heading */

.home-container h1{
    color:#0f172a;
    margin-bottom:10px;
    font-size:32px;
}

.home-container p{
    color:gray;
    margin-bottom:35px;
    line-height:1.6;
}

/* Buttons */

.btn-group{
    display:flex;
    flex-direction:column;
    gap:18px;
}

.btn{
    text-decoration:none;
    padding:14px;
    border-radius:12px;
    font-size:17px;
    font-weight:bold;
    transition:0.3s;
}

/* Login Button */

.login-btn{
    background:#2563eb;
    color:white;
}

.login-btn:hover{
    background:#1d4ed8;
    transform:translateY(-2px);
}

/* Register Button */

.register-btn{
    background:#e2e8f0;
    color:#0f172a;
}

.register-btn:hover{
    background:#cbd5e1;
    transform:translateY(-2px);
}

/* Footer */

.footer{
    margin-top:30px;
    color:gray;
    font-size:14px;
}

</style>

</head>

<body>

<div class="home-container">

<div class="logo">

IMS

</div>

<h1>Industry Management System</h1>

<p>
Manage industries, departments, employees and projects
through a centralized management platform.
</p>

<div class="btn-group">

<a href="login.jsp" class="btn login-btn">

Login

</a>

<a href="register.jsp" class="btn register-btn">

Register

</a>

</div>

<div class="footer">

Powered by JSP, Servlet & MySQL

</div>

</div>

</body>
</html>