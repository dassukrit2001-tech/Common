<%
if(session.getAttribute("user")==null){

    response.sendRedirect("login.jsp");
    return;
}

String role = (String)session.getAttribute("role");

if(!role.equals("Admin")){

    response.sendRedirect("employeeDashboard.jsp");
    return;
}
%>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">
<title>Admin Dashboard</title>

<link rel="stylesheet" href="css/style.css">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family: Arial, sans-serif;
    background: #f4f7fc;
}

/* Sidebar */

.sidebar{
    width:250px;
    height:100vh;
    background:#1e293b;
    position:fixed;
    left:0;
    top:0;
    padding-top:20px;
}

.sidebar h2{
    color:white;
    text-align:center;
    margin-bottom:40px;
    font-size:28px;
}

.sidebar a{
    display:block;
    color:#cbd5e1;
    text-decoration:none;
    padding:15px 25px;
    font-size:16px;
    transition:0.3s;
}

.sidebar a:hover{
    background:#334155;
    color:white;
    padding-left:35px;
}

/* Main Content */

.main{
    margin-left:250px;
    padding:30px;
}

.topbar{
    background:white;
    padding:20px;
    border-radius:12px;
    box-shadow:0 2px 10px rgba(0,0,0,0.1);
    margin-bottom:30px;
}

.topbar h1{
    color:#1e293b;
    margin-bottom:10px;
}

.topbar p{
    color:gray;
    font-size:16px;
}

/* Cards */

.card-container{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
    gap:20px;
    margin-bottom:30px;
}

.card{
    background:white;
    padding:25px;
    border-radius:15px;
    box-shadow:0 4px 15px rgba(0,0,0,0.08);
    transition:0.3s;
}

.card:hover{
    transform:translateY(-5px);
}

.card h2{
    color:#0f172a;
    margin-bottom:10px;
}

.card p{
    color:gray;
    margin-bottom:20px;
}

.card a{
    display:inline-block;
    text-decoration:none;
    background:#2563eb;
    color:white;
    padding:10px 18px;
    border-radius:8px;
    transition:0.3s;
}

.card a:hover{
    background:#1d4ed8;
}

/* Permission Box */

.permission-box{
    background:white;
    padding:25px;
    border-radius:15px;
    box-shadow:0 4px 15px rgba(0,0,0,0.08);
}

.permission-box h2{
    margin-bottom:20px;
    color:#0f172a;
}

.permission-box ul{
    list-style:none;
}

.permission-box ul li{
    padding:12px;
    margin-bottom:10px;
    background:#eff6ff;
    border-left:5px solid #2563eb;
    border-radius:5px;
    color:#1e293b;
}

</style>

</head>

<body>

<!-- Sidebar -->

<div class="sidebar">

<h2>Admin Panel</h2>

<a href="adminDashboard.jsp">Dashboard</a>

<a href="industry.jsp">Industry</a>

<a href="department.jsp">Department</a>

<a href="employee.jsp">Employee</a>

<a href="project.jsp">Project</a>

<a href="LogoutServlet">Logout</a>

</div>

<!-- Main Section -->

<div class="main">

<!-- Topbar -->

<div class="topbar">

<h1>Welcome Admin</h1>

<p>
Hello,
<b><%= session.getAttribute("name") %></b>
</p>

</div>

<!-- Cards -->

<div class="card-container">

<div class="card">

<h2>Industry</h2>

<p>Manage all industry records and details.</p>

<a href="industry.jsp">Open Module</a>

</div>

<div class="card">

<h2>Department</h2>

<p>Manage departments and organizational structure.</p>

<a href="department.jsp">Open Module</a>

</div>

<div class="card">

<h2>Employee</h2>

<p>Manage employee information and records.</p>

<a href="employee.jsp">Open Module</a>

</div>

<div class="card">

<h2>Project</h2>

<p>Manage project assignments and tracking.</p>

<a href="project.jsp">Open Module</a>

</div>

</div>

<!-- Permission Section -->

<div class="permission-box">

<h2>Admin Permissions</h2>

<ul>

<li>Add New Records</li>

<li>Update Existing Records</li>

<li>Delete Records</li>

<li>Manage All System Modules</li>

<li>Full CRUD Access</li>

<li>Monitor Employee Activities</li>

</ul>

</div>

</div>

</body>
</html>