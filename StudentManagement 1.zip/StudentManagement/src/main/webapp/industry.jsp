<%@page import="java.util.ArrayList"%>
<%@page import="dao.IndustryDAO"%>
<%@page import="model.Industry"%>

<%
if(session.getAttribute("user")==null){

    response.sendRedirect("login.jsp");
    return;
}

String role = (String)session.getAttribute("role");
%>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">
<title>Industry Management</title>

<link rel="stylesheet" href="css/style.css">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family: Arial, sans-serif;
    background:#f1f5f9;
}

/* Navbar */

.navbar{
    width:100%;
    background:#0f172a;
    padding:18px 40px;
    display:flex;
    justify-content:space-between;
    align-items:center;
}

.logo{
    color:white;
    font-size:24px;
    font-weight:bold;
}

.nav-links a{
    color:white;
    text-decoration:none;
    margin-left:20px;
    transition:0.3s;
}

.nav-links a:hover{
    color:#38bdf8;
}

/* Container */

.container{
    width:92%;
    margin:30px auto;
}

/* Header */

.page-header{
    margin-bottom:25px;
}

.page-header h1{
    color:#0f172a;
    margin-bottom:8px;
}

.page-header p{
    color:gray;
}

.role-badge{
    display:inline-block;
    margin-top:10px;
    background:#dbeafe;
    color:#1d4ed8;
    padding:7px 16px;
    border-radius:25px;
    font-size:14px;
    font-weight:bold;
}

/* Form Section */

.form-card{
    background:white;
    padding:30px;
    border-radius:18px;
    box-shadow:0 5px 15px rgba(0,0,0,0.08);
    margin-bottom:30px;
}

.form-card h2{
    margin-bottom:20px;
    color:#0f172a;
}

.form-grid{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:20px;
}

.form-group{
    display:flex;
    flex-direction:column;
}

.form-group label{
    margin-bottom:8px;
    font-weight:bold;
    color:#334155;
}

.form-group input,
.form-group select{
    padding:12px;
    border:1px solid #cbd5e1;
    border-radius:10px;
    font-size:15px;
}

.form-group input:focus,
.form-group select:focus{
    border-color:#2563eb;
    outline:none;
}

/* Button */

.submit-btn{
    margin-top:25px;
    background:#2563eb;
    color:white;
    border:none;
    padding:13px 24px;
    border-radius:10px;
    cursor:pointer;
    font-size:16px;
    transition:0.3s;
}

.submit-btn:hover{
    background:#1d4ed8;
}

/* Table Section */

.table-card{
    background:white;
    padding:25px;
    border-radius:18px;
    box-shadow:0 5px 15px rgba(0,0,0,0.08);
    overflow-x:auto;
}

.table-card h2{
    margin-bottom:20px;
    color:#0f172a;
}

table{
    width:100%;
    border-collapse:collapse;
}

table th{
    background:#2563eb;
    color:white;
    padding:14px;
    text-align:left;
}

table td{
    padding:14px;
    border-bottom:1px solid #e2e8f0;
}

table tr:hover{
    background:#f8fafc;
}

/* Buttons */

.edit-btn{
    text-decoration:none;
    background:#22c55e;
    color:white;
    padding:8px 12px;
    border-radius:6px;
    margin-right:6px;
    transition:0.3s;
}

.edit-btn:hover{
    background:#16a34a;
}

.delete-btn{
    text-decoration:none;
    background:#ef4444;
    color:white;
    padding:8px 12px;
    border-radius:6px;
    transition:0.3s;
}

.delete-btn:hover{
    background:#dc2626;
}

.view-only{
    color:#64748b;
    font-weight:bold;
}

/* Responsive */

@media(max-width:768px){

    .form-grid{
        grid-template-columns:1fr;
    }

    .navbar{
        flex-direction:column;
        gap:15px;
    }
}

</style>

</head>

<body>

<!-- Navbar -->

<div class="navbar">

<div class="logo">

Industry Panel

</div>

<div class="nav-links">

<%
if(role.equals("Admin")){
%>

<a href="adminDashboard.jsp">Dashboard</a>

<%
}else{
%>

<a href="employeeDashboard.jsp">Dashboard</a>

<%
}
%>

<a href="LogoutServlet">Logout</a>

</div>

</div>

<!-- Main Container -->

<div class="container">

<!-- Header -->

<div class="page-header">

<h1>Industry Management</h1>

<p>
Manage industries, locations and organization categories
</p>

<div class="role-badge">

Logged in as :
<%= role %>

</div>

</div>

<%
if(role.equals("Admin")){
%>

<!-- Add Industry Form -->

<div class="form-card">

<h2>Add New Industry</h2>

<form action="IndustryServlet" method="post">

<input type="hidden" name="action" value="add">

<div class="form-grid">

<div class="form-group">

<label>Industry Name</label>

<input type="text"
name="industryName"
required>

</div>

<div class="form-group">

<label>Location</label>

<input type="text"
name="location"
required>

</div>

<div class="form-group">

<label>Industry Type</label>

<select name="type">

<option>Manufacturing</option>
<option>IT</option>
<option>Service</option>

</select>

</div>

</div>

<input type="submit"
value="Add Industry"
class="submit-btn">

</form>

</div>

<%
}
%>

<!-- Industry Table -->

<div class="table-card">

<h2>Industry Records</h2>

<table>

<tr>

<th>ID</th>
<th>Industry Name</th>
<th>Location</th>
<th>Type</th>
<th>Action</th>

</tr>

<%
IndustryDAO dao = new IndustryDAO();

ArrayList<Industry> list =
dao.getAllIndustries();

for(Industry i : list){
%>

<tr>

<td><%= i.getIndustryId() %></td>

<td><%= i.getIndustryName() %></td>

<td><%= i.getLocation() %></td>

<td><%= i.getType() %></td>

<td>

<%
if(role.equals("Admin")){
%>

<a class="edit-btn"
href="IndustryServlet?action=edit&id=<%= i.getIndustryId() %>">

Edit

</a>

<a class="delete-btn"
href="IndustryServlet?action=delete&id=<%= i.getIndustryId() %>">

Delete

</a>

<%
}else{
%>

<span class="view-only">

View Only

</span>

<%
}
%>

</td>

</tr>

<%
}
%>

</table>

</div>

</div>

</body>
</html>