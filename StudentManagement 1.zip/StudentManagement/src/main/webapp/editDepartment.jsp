<%
if(session.getAttribute("user")==null){

    response.sendRedirect("login.jsp");
    return;
}

String role = (String)session.getAttribute("role");

if(!role.equals("Admin")){

    response.sendRedirect("employeeDashboard.jsp");
    return;
}
%>

<%@page import="model.Department"%>

<%
Department d =
(Department)request.getAttribute("department");
%>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">
<title>Edit Department</title>

<link rel="stylesheet" href="css/style.css">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family: Arial, sans-serif;
    background: linear-gradient(to right, #e0f2fe, #f8fafc);
    min-height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
}

/* Main Card */

.edit-container{
    width:500px;
    background:white;
    padding:35px;
    border-radius:18px;
    box-shadow:0 8px 25px rgba(0,0,0,0.12);
}

/* Header */

.header{
    text-align:center;
    margin-bottom:30px;
}

.header h2{
    color:#0f172a;
    margin-bottom:8px;
    font-size:30px;
}

.header p{
    color:gray;
    font-size:15px;
}

/* Form */

.form-group{
    margin-bottom:20px;
}

.form-group label{
    display:block;
    margin-bottom:8px;
    font-weight:bold;
    color:#334155;
}

.form-group input{
    width:100%;
    padding:13px;
    border:1px solid #cbd5e1;
    border-radius:10px;
    font-size:15px;
    transition:0.3s;
}

.form-group input:focus{
    border-color:#2563eb;
    outline:none;
    box-shadow:0 0 5px rgba(37,99,235,0.4);
}

/* Buttons */

.button-group{
    display:flex;
    justify-content:space-between;
    margin-top:25px;
}

.update-btn{
    background:#2563eb;
    color:white;
    border:none;
    padding:12px 20px;
    border-radius:10px;
    cursor:pointer;
    font-size:16px;
    transition:0.3s;
}

.update-btn:hover{
    background:#1d4ed8;
}

.back-btn{
    background:#64748b;
    color:white;
    text-decoration:none;
    padding:12px 20px;
    border-radius:10px;
    transition:0.3s;
}

.back-btn:hover{
    background:#475569;
}

/* Department ID Badge */

.badge{
    display:inline-block;
    background:#dbeafe;
    color:#1d4ed8;
    padding:6px 14px;
    border-radius:20px;
    font-size:14px;
    margin-top:10px;
}

</style>

</head>

<body>

<div class="edit-container">

<div class="header">

<h2>Edit Department</h2>

<p>
Update department details below
</p>

<div class="badge">
Department ID :
<%= d.getDeptId() %>
</div>

</div>

<form action="DepartmentServlet" method="post">

<input type="hidden" name="action" value="update">

<input type="hidden"
name="deptId"
value="<%= d.getDeptId() %>">

<div class="form-group">

<label>Department Name</label>

<input type="text"
name="deptName"
value="<%= d.getDeptName() %>"
required>

</div>

<div class="form-group">

<label>Industry ID</label>

<input type="text"
name="industryId"
value="<%= d.getIndustryId() %>"
required>

</div>

<div class="form-group">

<label>Manager Name</label>

<input type="text"
name="managerName"
value="<%= d.getManagerName() %>"
required>

</div>

<div class="button-group">

<a href="department.jsp" class="back-btn">
Back
</a>

<input type="submit"
value="Update Department"
class="update-btn">

</div>

</form>

</div>

</body>
</html>