<%@page import="java.util.ArrayList"%>
<%@page import="dao.ProjectDAO"%>
<%@page import="dao.DepartmentDAO"%>
<%@page import="model.Project"%>
<%@page import="model.Department"%>

<%
if(session.getAttribute("user")==null){

    response.sendRedirect("login.jsp");
    return;
}

String role = (String)session.getAttribute("role");
%>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">
<title>Project Management</title>

<link rel="stylesheet" href="css/style.css">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family: Arial, sans-serif;
    background:#f1f5f9;
}

/* Navbar */

.navbar{
    width:100%;
    background:#0f172a;
    padding:18px 40px;
    display:flex;
    justify-content:space-between;
    align-items:center;
}

.logo{
    color:white;
    font-size:24px;
    font-weight:bold;
}

.nav-links a{
    color:white;
    text-decoration:none;
    margin-left:20px;
    transition:0.3s;
}

.nav-links a:hover{
    color:#38bdf8;
}

/* Container */

.container{
    width:92%;
    margin:30px auto;
}

/* Header */

.page-header{
    margin-bottom:25px;
}

.page-header h1{
    color:#0f172a;
    margin-bottom:8px;
}

.page-header p{
    color:gray;
}

.role-badge{
    display:inline-block;
    margin-top:10px;
    background:#dbeafe;
    color:#1d4ed8;
    padding:7px 16px;
    border-radius:25px;
    font-size:14px;
    font-weight:bold;
}

/* Form Card */

.form-card{
    background:white;
    padding:30px;
    border-radius:18px;
    box-shadow:0 5px 15px rgba(0,0,0,0.08);
    margin-bottom:30px;
}

.form-card h2{
    margin-bottom:20px;
    color:#0f172a;
}

.form-grid{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:20px;
}

.form-group{
    display:flex;
    flex-direction:column;
}

.form-group label{
    margin-bottom:8px;
    font-weight:bold;
    color:#334155;
}

.form-group input,
.form-group select{
    padding:12px;
    border:1px solid #cbd5e1;
    border-radius:10px;
    font-size:15px;
}

.form-group input:focus,
.form-group select:focus{
    border-color:#2563eb;
    outline:none;
}

/* Submit Button */

.submit-btn{
    margin-top:25px;
    background:#2563eb;
    color:white;
    border:none;
    padding:13px 24px;
    border-radius:10px;
    cursor:pointer;
    font-size:16px;
    transition:0.3s;
}

.submit-btn:hover{
    background:#1d4ed8;
}

/* Table Card */

.table-card{
    background:white;
    padding:25px;
    border-radius:18px;
    box-shadow:0 5px 15px rgba(0,0,0,0.08);
    overflow-x:auto;
}

.table-card h2{
    margin-bottom:20px;
    color:#0f172a;
}

table{
    width:100%;
    border-collapse:collapse;
}

table th{
    background:#2563eb;
    color:white;
    padding:14px;
    text-align:left;
}

table td{
    padding:14px;
    border-bottom:1px solid #e2e8f0;
}

table tr:hover{
    background:#f8fafc;
}

/* Status Badges */

.status{
    padding:7px 12px;
    border-radius:20px;
    font-size:13px;
    font-weight:bold;
    display:inline-block;
}

.pending{
    background:#fef3c7;
    color:#92400e;
}

.progress{
    background:#dbeafe;
    color:#1d4ed8;
}

.completed{
    background:#dcfce7;
    color:#166534;
}

/* Action Buttons */

.edit-btn{
    text-decoration:none;
    background:#22c55e;
    color:white;
    padding:8px 12px;
    border-radius:6px;
    margin-right:6px;
    transition:0.3s;
}

.edit-btn:hover{
    background:#16a34a;
}

.delete-btn{
    text-decoration:none;
    background:#ef4444;
    color:white;
    padding:8px 12px;
    border-radius:6px;
    transition:0.3s;
}

.delete-btn:hover{
    background:#dc2626;
}

/* Responsive */

@media(max-width:768px){

    .form-grid{
        grid-template-columns:1fr;
    }

    .navbar{
        flex-direction:column;
        gap:15px;
    }
}

</style>

</head>

<body>

<!-- Navbar -->

<div class="navbar">

<div class="logo">

Project Panel

</div>

<div class="nav-links">

<%
if(role.equals("Admin")){
%>

<a href="adminDashboard.jsp">Dashboard</a>

<%
}else{
%>

<a href="employeeDashboard.jsp">Dashboard</a>

<%
}
%>

<a href="LogoutServlet">Logout</a>

</div>

</div>

<!-- Main Container -->

<div class="container">

<!-- Header -->

<div class="page-header">

<h1>Project Management</h1>

<p>
Manage projects, department assignments and progress tracking
</p>

<div class="role-badge">

Logged in as :
<%= role %>

</div>

</div>

<%
if(role.equals("Admin")){
%>

<!-- Add Project Form -->

<div class="form-card">

<h2>Add New Project</h2>

<form action="ProjectServlet" method="post">

<input type="hidden" name="action" value="add">

<div class="form-grid">

<div class="form-group">

<label>Project Name</label>

<input type="text"
name="projectName"
required>

</div>

<div class="form-group">

<label>Department</label>

<select name="deptId">

<%
DepartmentDAO deptDAO = new DepartmentDAO();

ArrayList<Department> departments =
deptDAO.getAllDepartments();

for(Department dep : departments){
%>

<option value="<%= dep.getDeptId() %>">

<%= dep.getDeptName() %>

</option>

<%
}
%>

</select>

</div>

<div class="form-group">

<label>Start Date</label>

<input type="date"
name="startDate"
required>

</div>

<div class="form-group">

<label>End Date</label>

<input type="date"
name="endDate"
required>

</div>

<div class="form-group">

<label>Project Status</label>

<select name="status">

<option>Pending</option>
<option>In Progress</option>
<option>Completed</option>

</select>

</div>

</div>

<input type="submit"
value="Add Project"
class="submit-btn">

</form>

</div>

<%
}
%>

<!-- Project Table -->

<div class="table-card">

<h2>Project Records</h2>

<table>

<tr>

<th>ID</th>
<th>Project Name</th>
<th>Start Date</th>
<th>End Date</th>
<th>Department ID</th>
<th>Status</th>

<%
if(role.equals("Admin")){
%>

<th>Actions</th>

<%
}
%>

</tr>

<%
ProjectDAO dao = new ProjectDAO();

ArrayList<Project> list =
dao.getAllProjects();

for(Project p : list){
%>

<tr>

<td><%= p.getProjectId() %></td>

<td><%= p.getProjectName() %></td>

<td><%= p.getStartDate() %></td>

<td><%= p.getEndDate() %></td>

<td><%= p.getDeptId() %></td>

<td>

<%
if(p.getStatus().equals("Pending")){
%>

<span class="status pending">

Pending

</span>

<%
}else if(p.getStatus().equals("In Progress")){
%>

<span class="status progress">

In Progress

</span>

<%
}else{
%>

<span class="status completed">

Completed

</span>

<%
}
%>

</td>

<%
if(role.equals("Admin")){
%>

<td>

<a class="edit-btn"
href="ProjectServlet?action=edit&id=<%= p.getProjectId() %>">

Edit

</a>

<a class="delete-btn"
href="ProjectServlet?action=delete&id=<%= p.getProjectId() %>">

Delete

</a>

</td>

<%
}
%>

</tr>

<%
}
%>

</table>

</div>

</div>

</body>
</html>